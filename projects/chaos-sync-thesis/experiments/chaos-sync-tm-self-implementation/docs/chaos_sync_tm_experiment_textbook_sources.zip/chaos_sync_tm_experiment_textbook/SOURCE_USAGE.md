# 添付資料の利用範囲

本テキストは、次の役割分担で添付資料を参照しています。

1. **2024年度数理工学実験テキスト**
   - 目的、原理、実験方法、結果、考察、結論という報告構造
   - 第三者が再現できるパラメータ・図表・式番号・参考文献の記載

2. **Infinite Dimensional Chaotic Synchronization...**
   - 一般化Boole写像、Cauchy尺度写像、加法的ランダム結合モデル、条件付きLyapunov指数、臨界結合の原稿内主張
   - 有限Nの同期多様体不変性や行和条件は、独立監査対象として明示

3. **Universal Mass Gap Formula...**
   - Cauchy不変測度、Cayley変換、TM power basis、K-fold cotangent写像のKoopman shiftを実装正対照として利用
   - KMS、mass gap、QFT等の主張は実験の中核仮定から除外

4. **Artificial Kuramoto Oscillatory Neurons**
   - 有限時間の動力学ブロック、入力刺激、結合、位相不変readout、ablation、test-time反復の設計参考
   - カオス同期・Cauchy・TMを扱う研究ではない点を区別

5. **E1からE5の実験解説、README、AGENTS**
   - E/T系統をE0〜E5へ統一する実験依存関係
   - 「同期縮約と情報保持を分離する」「TMは読み出し座標」という研究上の境界
   - E0〜E3を卒論最小スコープとする運用方針

本文では、標準事実、資料中の主張、本テキストでの導出、数値既存値、仮説をラベルで区別しています。

# <EID> 実験ノート

## 1. 研究質問

## 2. 帰無仮説・対立仮説

## 3. 事前固定
- 操作変数:
- 固定変数:
- seed単位:
- split単位:
- primary metric:
- Gate:
- 停止条件:

## 4. 理論

## 5. 実装
- commit:
- environment:
- config hash:
- Why not（採用しなかった実装）:

## 6. 結果

## 7. Gate判定

## 8. 考察
- 理論との一致:
- 代替説明:
- 数値誤差:
- 限界:

## 9. 次の単一仮説

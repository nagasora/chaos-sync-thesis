# カオス同期・TM読み出し 数値実験テキスト

## 内容

- `main.tex`: 実験テキストのLaTeX正本
- `starter/`: 自分で実装するためのPythonパッケージ骨格、設定、仕様テスト
- `templates/`: 実験ノートとレポートのテンプレート

PDFは、E0（局所写像）からE5（画像pilot）までを、理論、実験手順、比較条件、Gate、考察課題、再現性契約の順で構成しています。

## PDFのビルド

LuaLaTeXと日本語フォントが利用できる環境で、次を実行します。

```bash
latexmk -lualatex -outdir=build main.tex
```

`latexmk`がない場合は、相互参照を解決するために次を2回実行します。

```bash
lualatex -interaction=nonstopmode -output-directory=build main.tex
lualatex -interaction=nonstopmode -output-directory=build main.tex
```

## Pythonスターター

```bash
cd starter
python -m venv .venv
# Windows PowerShell
.venv\Scripts\Activate.ps1
python -m pip install -U pip
python -m pip install -e ".[dev]"
pytest -q tests/test_scaffold.py
```

`tests/test_scaffold.py`はスターター自体の確認です。次はE0A/E0Bを実装しながら、以下の仕様テストを通します。

```bash
pytest -q -m exercise
```

`exercise`テストは、未実装の間は失敗するよう意図されています。

## 最初の実装順

1. `maps.generalized_boole`
2. `maps.boole_derivative`
3. `maps.simulate_boole_orbit`
4. `features.cayley_mode`
5. `features.complex_lag_correlation`
6. `features.tm_feature_vector`
7. `features.fourier_log_band_energy`
8. `coupling.output_mixing_step`

## 重要な境界

- 同期による自由度縮約と、入力情報を保持した圧縮は同一ではありません。
- TM基底は、観測写像が捨てた情報を新たに作りません。
- 添付原稿の加法的ランダム結合モデルの臨界式と、本テキストのrow-stochastic出力混合モデルの臨界式は別物です。
- KMS状態・質量ギャップ等の強い物理的主張は、本実験の中核仮定には採用していません。
- E0〜E3が卒論の最小スコープで、E4・E5は基礎検証後の拡張です。

"""カオス同期・情報圧縮実験の教育用スターターパッケージ。"""

from .configs import OrbitConfig, OutputMixingConfig
from .theory import boole_gamma_star, boole_lyapunov, output_mixing_critical_coupling

__all__ = [
    "OrbitConfig",
    "OutputMixingConfig",
    "boole_gamma_star",
    "boole_lyapunov",
    "output_mixing_critical_coupling",
]

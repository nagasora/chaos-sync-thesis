"""同期・復元・潜在次元指標。"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def synchronization_rms(state: FloatArray) -> float:
    """How: ノード平均との差のRMSを返す。"""

    center = float(np.mean(state))
    return float(np.sqrt(np.mean((state - center) ** 2)))


def robust_sync_dispersion(state: FloatArray) -> float:
    """How: ノードmedianからの絶対偏差medianを返す。"""

    center = float(np.median(state))
    return float(np.median(np.abs(state - center)))


def normalized_mse(target: FloatArray, prediction: FloatArray, eps: float = 1.0e-12) -> float:
    """How: targetの中心化エネルギーでMSEを正規化する。"""

    if target.shape != prediction.shape:
        raise ValueError("target と prediction のshapeが一致する必要があります。")
    numerator = float(np.sum((target - prediction) ** 2))
    denominator = float(np.sum((target - np.mean(target)) ** 2))
    return numerator / max(denominator, eps)


def effective_rank_svd(features: FloatArray, eps: float = 1.0e-15) -> float:
    """How: 特異値participation ratioで有効次元を返す。"""

    singular_values = np.linalg.svd(features, full_matrices=False, compute_uv=False)
    energy = singular_values**2
    return float((energy.sum() ** 2) / max(float(np.sum(energy**2)), eps))

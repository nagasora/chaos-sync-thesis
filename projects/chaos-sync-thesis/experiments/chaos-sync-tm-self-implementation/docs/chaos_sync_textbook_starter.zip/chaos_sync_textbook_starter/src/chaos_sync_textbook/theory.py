"""解析式だけを集めた副作用のない関数。

How:
数値軌道を生成する実装と、比較対象となる理論値を分離する。
"""

from __future__ import annotations

import math


def boole_gamma_star(alpha: float) -> float:
    """How: 一般化Boole写像の正のCauchy尺度固定点を返す。"""

    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha は 0 < alpha < 1 を満たす必要があります。")
    return math.sqrt(alpha / (1.0 - alpha))


def boole_lyapunov(alpha: float) -> float:
    """How: 不変Cauchy測度下のLyapunov閉形式を返す。"""

    if not 0.0 < alpha < 1.0:
        raise ValueError("alpha は 0 < alpha < 1 を満たす必要があります。")
    return 2.0 * math.log(math.sqrt(alpha) + math.sqrt(1.0 - alpha))


def output_mixing_critical_coupling(alpha: float) -> float:
    """How: W=11^T/N の出力混合モデルの下側局所臨界を返す。"""

    return 1.0 - math.exp(-boole_lyapunov(alpha))


def source_claim_random_additive_kc(alpha: float, mean_abs_weight: float) -> float:
    """How: 添付原稿が主張する加法的ランダム結合の臨界式を返す。

    注意:
    この式は source claim の比較用であり、output-mixingモデルには使用しない。
    """

    if mean_abs_weight <= 0.0:
        raise ValueError("mean_abs_weight は正である必要があります。")
    return 2.0 * math.sqrt(alpha) * (1.0 - math.sqrt(alpha)) / mean_abs_weight

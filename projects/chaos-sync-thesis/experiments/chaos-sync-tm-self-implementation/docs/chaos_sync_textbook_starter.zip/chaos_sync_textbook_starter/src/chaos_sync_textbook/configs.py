"""実験設定の不変データクラス。

How:
辞書をrunner間で渡すのではなく、検証付きdataclassで実験契約を固定する。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class OrbitConfig:
    """How: 単一軌道の反復条件を不変オブジェクトとして保持する。"""

    alpha: float
    burn_in: int
    n_steps: int
    seed: int
    dtype: str = "float64"
    singularity_tol: float = 1.0e-12

    def validate(self) -> None:
        """How: 実行前に、理論範囲と計数条件を検査する。"""

        if not 0.0 < self.alpha < 1.0:
            raise ValueError("alpha は 0 < alpha < 1 を満たす必要があります。")
        if self.burn_in < 0 or self.n_steps <= 0:
            raise ValueError("burn_in >= 0 かつ n_steps > 0 が必要です。")
        if self.dtype not in {"float32", "float64", "longdouble"}:
            raise ValueError("dtype は float32/float64/longdouble のいずれかです。")
        if self.singularity_tol <= 0.0:
            raise ValueError("singularity_tol は正である必要があります。")


@dataclass(frozen=True)
class OutputMixingConfig:
    """How: row-stochastic出力混合ネットワークの条件を保持する。"""

    n_nodes: int
    alpha: float
    coupling: float
    input_gain: float
    n_steps: int
    seed: int

    def validate(self) -> None:
        """How: ネットワーク設定の定義域を実行前に検査する。"""

        if self.n_nodes < 2:
            raise ValueError("n_nodes は2以上である必要があります。")
        if not 0.0 < self.alpha < 1.0:
            raise ValueError("alpha は 0 < alpha < 1 を満たす必要があります。")
        if not 0.0 <= self.coupling <= 1.0:
            raise ValueError("基本実験では coupling を [0, 1] に制限します。")
        if self.n_steps <= 0:
            raise ValueError("n_steps は正である必要があります。")


@dataclass(frozen=True)
class RunPaths:
    """How: 一つのrunに属するartifactの保存先を一元管理する。"""

    root: Path

    @property
    def metrics_csv(self) -> Path:
        """How: 未集約指標CSVの保存先を返す。"""

        return self.root / "metrics.csv"

    @property
    def summary_json(self) -> Path:
        """How: 集約結果JSONの保存先を返す。"""

        return self.root / "summary.json"

    @property
    def predictions_npz(self) -> Path:
        """How: 全予測と潜在表現の保存先を返す。"""

        return self.root / "predictions.npz"

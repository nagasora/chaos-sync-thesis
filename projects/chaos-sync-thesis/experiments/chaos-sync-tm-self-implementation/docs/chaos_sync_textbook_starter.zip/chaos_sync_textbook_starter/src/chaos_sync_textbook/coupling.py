"""結合行列・ネットワーク更新・同期多様体検査の演習実装。"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def mean_field_weight(n_nodes: int) -> FloatArray:
    """How: W=11^T/N のrow-stochastic全平均行列を返す。"""

    if n_nodes < 2:
        raise ValueError("n_nodes は2以上である必要があります。")
    return np.full((n_nodes, n_nodes), 1.0 / n_nodes, dtype=np.float64)


def assert_row_stochastic(weight: FloatArray, atol: float = 1.0e-12) -> None:
    """How: 非負性と行和1を検査し、不変性の前提を保証する。"""

    if weight.ndim != 2 or weight.shape[0] != weight.shape[1]:
        raise ValueError("weight は正方行列である必要があります。")
    if np.any(weight < -atol):
        raise ValueError("基本output-mixingでは負の重みを許しません。")
    if not np.allclose(weight.sum(axis=1), 1.0, atol=atol, rtol=0.0):
        raise ValueError("weight の各行和は1である必要があります。")


def output_mixing_step(
    state: FloatArray,
    alpha: float,
    coupling: float,
    weight: FloatArray,
    common_input: float = 0.0,
) -> FloatArray:
    """How: [(1-K)I+KW]F_alpha(state)+u*1 を1step計算する。"""

    # Why not: 行和を実行中に自動正規化すると、事前固定したモデルと別物になる。
    raise NotImplementedError("E3C課題: 不変性テストとともに実装してください。")

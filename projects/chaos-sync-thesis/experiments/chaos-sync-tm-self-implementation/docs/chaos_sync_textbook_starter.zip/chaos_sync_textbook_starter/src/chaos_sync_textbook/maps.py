"""局所写像と軌道生成の演習実装。

How:
E0Aで最初に完成させる。特異点を隠さず、診断情報とともに返す設計にする。
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from .configs import OrbitConfig

FloatArray = NDArray[np.float64]


@dataclass(frozen=True)
class OrbitDiagnostics:
    """How: 軌道中の数値破綻を集約せず保存する。"""

    near_singularity_count: int
    nonfinite_count: int
    max_abs_state: float


def generalized_boole(x: FloatArray, alpha: float) -> FloatArray:
    """How: F_alpha(x)=alpha*(x-1/x) を要素ごとに計算する。"""

    # Why not: xを暗黙clipすると元の力学系を変更するため、ここでは未実装のままにする。
    raise NotImplementedError("E0A課題: 特異点診断を含めて実装してください。")


def boole_derivative(x: FloatArray, alpha: float) -> FloatArray:
    """How: F'_alpha(x)=alpha*(1+1/x^2) を要素ごとに計算する。"""

    raise NotImplementedError("E0A課題: 微分を実装してください。")


def simulate_boole_orbit(config: OrbitConfig, x0: float) -> tuple[FloatArray, OrbitDiagnostics]:
    """How: burn-in後の計測軌道と数値診断を返す。"""

    config.validate()
    raise NotImplementedError("E0A課題: 軌道生成と診断を実装してください。")


def kfold_cotangent(x: FloatArray, degree: int) -> FloatArray:
    """How: atan2でarccotの枝を固定し cot(K arccot x) を計算する。"""

    raise NotImplementedError("E0B課題: K-fold基準写像を実装してください。")

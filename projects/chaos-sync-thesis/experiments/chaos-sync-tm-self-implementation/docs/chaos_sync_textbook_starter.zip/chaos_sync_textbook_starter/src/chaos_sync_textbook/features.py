"""Cayley/TM・Fourier・graph時間特徴の演習実装。"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]
BoolArray = NDArray[np.bool_]


def cayley_mode(x: FloatArray, mu: float, gamma: float, order: int) -> ComplexArray:
    """How: Cauchy軌道を単位円上のTM power modeへ写す。"""

    if gamma <= 0.0:
        raise ValueError("gamma は正である必要があります。")
    if order == 0:
        return np.ones_like(x, dtype=np.complex128)
    raise NotImplementedError("E0B課題: Cayley変換と冪を実装してください。")


def complex_lag_correlation(
    z: ComplexArray,
    lags: tuple[int, ...],
    mask: BoolArray | None = None,
    min_pairs: int = 8,
) -> ComplexArray:
    """How: 観測pairだけを使い、複素lag相関を固定順で返す。"""

    # Why not: 欠測を0とみなすと、0が実測値であるという別の仮定を導入する。
    raise NotImplementedError("E1/E2課題: pairwise-complete相関を実装してください。")


def tm_feature_vector(
    x: FloatArray,
    orders: tuple[int, ...] = (1, 2, 3, 4),
    lags: tuple[int, ...] = (1, 2),
) -> FloatArray:
    """How: TM相関の実部・虚部を再現可能な順序で連結する。"""

    raise NotImplementedError("E1A課題: 16次元TM特徴を実装してください。")


def fourier_log_band_energy(x: FloatArray, n_bands: int = 16) -> FloatArray:
    """How: 窓付きrFFTパワーを固定帯域へ集約しlog-energyを返す。"""

    raise NotImplementedError("E1A課題: 容量一致Fourier baselineを実装してください。")

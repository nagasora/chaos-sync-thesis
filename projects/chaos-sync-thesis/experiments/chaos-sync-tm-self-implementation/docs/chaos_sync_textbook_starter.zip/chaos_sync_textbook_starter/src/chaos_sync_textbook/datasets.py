"""合成信号・二源観測・画像系列化の演習実装。"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def sine_signal(length: int, amplitude: float, frequency: float, phase: float) -> FloatArray:
    """How: cycles/window表記の正弦波を生成する。"""

    tau = np.linspace(0.0, 1.0, length, dtype=np.float64)
    return amplitude * np.sin(2.0 * np.pi * frequency * tau + phase)


def chirp_signal(
    length: int,
    amplitude: float,
    initial_frequency: float,
    chirp_rate: float,
    phase: float,
) -> FloatArray:
    """How: 位相を明示した二次chirpを生成する。"""

    tau = np.linspace(0.0, 1.0, length, dtype=np.float64)
    angle = 2.0 * np.pi * (
        initial_frequency * tau + 0.5 * chirp_rate * tau**2
    ) + phase
    return amplitude * np.sin(angle)


def flatten_digit_row_major(image: FloatArray) -> FloatArray:
    """How: 2次元画像をrow-major系列へ変換する。"""

    if image.ndim != 2:
        raise ValueError("image は2次元である必要があります。")
    return np.asarray(image, dtype=np.float64).reshape(-1)

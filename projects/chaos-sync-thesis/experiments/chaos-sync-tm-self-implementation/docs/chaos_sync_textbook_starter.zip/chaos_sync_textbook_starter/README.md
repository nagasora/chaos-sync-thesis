# カオス同期・情報圧縮 実装スターター

このディレクトリは、実験テキストを読みながら自分で実装するための骨格です。理論値と設定クラス、一部の単純な指標だけを実装済みにし、局所写像、TM特徴、結合更新は `NotImplementedError` の演習として残しています。

## 環境構築

```bash
python -m venv .venv
source .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -U pip
python -m pip install -e ".[dev]"
```

## 最初に行うテスト

スターター自体の確認:

```bash
pytest -q tests/test_scaffold.py
```

E0A/E0Bを実装しながら通す仕様テスト:

```bash
pytest -q -m exercise
```

## 実装順

1. `maps.generalized_boole`
2. `maps.boole_derivative`
3. `maps.simulate_boole_orbit`
4. `features.cayley_mode`
5. `features.complex_lag_correlation`
6. `features.tm_feature_vector`
7. `features.fourier_log_band_energy`
8. `coupling.output_mixing_step`

## 記述規約

- コードのdocstring: **How**
- テスト名・docstring: **What**
- コミットメッセージ: **Why**
- コードコメント: **Why not**

特異点を単純にclipしたり、行列を実行中に自動正規化したりしないでください。それらは元のモデルを変更するため、必要なら別EIDで比較します。

"""スターターパッケージ自体のsmoke test。"""

from __future__ import annotations

import math

import numpy as np

from chaos_sync_textbook.coupling import assert_row_stochastic, mean_field_weight
from chaos_sync_textbook.metrics import normalized_mse, synchronization_rms
from chaos_sync_textbook.theory import (
    boole_gamma_star,
    boole_lyapunov,
    output_mixing_critical_coupling,
)


def test_theory_reference_values() -> None:
    """What: alpha=1/2で gamma*=1, lambda=ln2, Kc=1/2 となること。"""

    assert math.isclose(boole_gamma_star(0.5), 1.0, rel_tol=0.0, abs_tol=1.0e-12)
    assert math.isclose(boole_lyapunov(0.5), math.log(2.0), abs_tol=1.0e-12)
    assert math.isclose(output_mixing_critical_coupling(0.5), 0.5, abs_tol=1.0e-12)


def test_mean_field_weight_is_row_stochastic() -> None:
    """What: 全平均行列の各行和が1であること。"""

    weight = mean_field_weight(8)
    assert_row_stochastic(weight)
    assert np.allclose(weight.sum(axis=1), 1.0)


def test_basic_metrics() -> None:
    """What: 完全同期のRMSは0で、完全再構成のNMSEは0であること。"""

    state = np.full(8, 0.7)
    assert synchronization_rms(state) == 0.0
    target = np.array([0.0, 1.0, 0.0])
    assert normalized_mse(target, target.copy()) == 0.0

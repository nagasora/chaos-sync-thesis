"""E0A/E0Bの仕様テスト。未実装の間は失敗するのが正常。"""

from __future__ import annotations

import numpy as np
import pytest

from chaos_sync_textbook.features import cayley_mode
from chaos_sync_textbook.maps import generalized_boole


@pytest.mark.exercise
def test_generalized_boole_matches_formula() -> None:
    """What: 実装値が alpha*(x-1/x) と一致すること。"""

    x = np.array([-2.0, -0.5, 0.5, 2.0], dtype=np.float64)
    alpha = 0.5
    actual = generalized_boole(x, alpha)
    expected = alpha * (x - 1.0 / x)
    assert np.allclose(actual, expected)


@pytest.mark.exercise
def test_cayley_mode_is_unimodular() -> None:
    """What: 有限な実数入力が単位円へ写ること。"""

    x = np.array([-10.0, -1.0, 0.0, 1.0, 10.0], dtype=np.float64)
    z = cayley_mode(x, mu=0.0, gamma=1.0, order=3)
    assert np.allclose(np.abs(z), 1.0, atol=1.0e-12)

﻿"""E0保存軌道を実験実装と独立な式・積分・再集計で監査する。"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Dict
import numpy as np
from scipy.integrate import quad


def validate(out: Path) -> Dict:
    """全軌道の一ステップ式、尺度・指数、周期、集計・ハッシュを検証する。"""
    config = json.loads((out/"config.json").read_text(encoding="utf-8"))
    summary = json.loads((out/"summary.json").read_text(encoding="utf-8"))
    env = json.loads((out/"environment.json").read_text(encoding="utf-8"))
    with (out/"metrics.csv").open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    with (out/"conditions.csv").open(encoding="utf-8") as f:
        conditions = list(csv.DictReader(f))
    checks = {}
    expected = len(config["alpha_values"])*len(config["seeds"])*len(config["initial_distributions"])
    checks["row_count"] = len(rows) == expected*len(config["precision"])*len(config["observation_lengths"])
    checks["unique_conditions"] = len({(r["dtype"],r["alpha"],r["seed"],r["initial_distribution"],r["length"]) for r in rows}) == len(rows)
    checks["condition_grid"] = {(float(r["alpha"]),int(r["seed"]),r["initial_distribution"]) for r in conditions} == {
        (a,s,d) for a in config["alpha_values"] for s in config["seeds"] for d in config["initial_distributions"]}
    theory = []
    for alpha in config["alpha_values"]:
        gamma = np.sqrt(alpha/(1-alpha))
        integral,error = quad(lambda theta: (np.log(alpha)+np.log1p((np.tan(theta)/gamma)**2))*2/np.pi,0,np.pi/2,epsabs=1e-10)
        closed = np.log1p(2*np.sqrt(alpha*(1-alpha)))
        checks[f"quadrature_{alpha}"] = abs(integral-closed) < 1e-8
        theory.append(dict(alpha=alpha,gamma=float(gamma),closed_form=float(closed),quadrature=integral,quadrature_error=error))
    for dtype in config["precision"]:
        data = np.load(out/f"orbits_{dtype}.npz")
        orbit = data["orbit"]
        checks[f"shape_dtype_{dtype}"] = orbit.shape == (expected,max(config["observation_lengths"])) and orbit.dtype.name == dtype
        a = np.array([float(r["alpha"]) for r in conditions],dtype=dtype)
        x = np.array([float(r["initial_state"]) for r in conditions],dtype=dtype)
        near = np.zeros((len(x),len(config["near_zero_thresholds"])),dtype=np.int64)
        failures = np.full(len(x),-1,dtype=np.int64)
        nf = np.zeros(len(x),dtype=np.int64)
        active = np.ones(len(x),dtype=bool)
        match = True
        # 共通モジュールをimportせず、保存初期値から全軌道を再演算する。
        with np.errstate(divide="ignore",invalid="ignore",over="ignore"):
            for step in range(config["burn_in"]+orbit.shape[1]):
                idx = np.flatnonzero(active)
                near[idx] += np.abs(x[idx,None]).astype(np.float64) < np.array(config["near_zero_thresholds"])
                reciprocal = np.divide(np.ones(len(idx),dtype=dtype),x[idx])
                x[idx] = np.multiply(a[idx],np.subtract(x[idx],reciprocal))
                bad = ~np.isfinite(x[idx]) | (x[idx] == 0)
                nf[idx] += ~np.isfinite(x[idx])
                failures[idx[bad]] = step+1
                active[idx[bad]] = False
                if step >= config["burn_in"]:
                    observed = orbit[:,step-config["burn_in"]]
                    expected_col = np.full(len(x),np.nan,dtype=dtype)
                    expected_col[idx] = x[idx]
                    match = match and np.array_equal(observed,expected_col,equal_nan=True)
        checks[f"independent_exact_replay_{dtype}"] = match
        checks[f"diagnostic_counts_{dtype}"] = bool(np.array_equal(near,data["near_zero_counts"]) and np.array_equal(failures,data["failure_step"]) and np.array_equal(nf,data["nonfinite_update_count"]))
        metric_ok = True
        period_ok = True
        for r in [r for r in rows if r["dtype"] == dtype]:
            values = orbit[int(r["condition_index"]),:int(r["length"])].astype(np.float64)
            complete = bool(np.all(np.isfinite(values) & (values != 0)))
            metric_ok &= complete == (r["completed"] == "True")
            if complete:
                alpha = float(r["alpha"])
                gamma = np.sqrt(alpha/(1-alpha))
                med = np.quantile(values,.5)
                mad = np.quantile(np.abs(values-med),.5)
                lyap = np.mean(np.log(alpha*(1+1/values**2)))
                targets = dict(median=med,mad=mad,half_iqr=(np.quantile(values,.75)-np.quantile(values,.25))/2,
                    mad_absolute_error=abs(mad-gamma),mad_relative_error=abs(mad/gamma-1),
                    estimated_lyapunov=lyap,lyapunov_absolute_error=abs(lyap-np.log1p(2*np.sqrt(alpha*(1-alpha)))),
                    sample_mean=np.mean(values),sample_std=np.std(values))
                metric_ok &= all(np.isclose(float(r[k]),v,rtol=1e-11,atol=1e-12) for k,v in targets.items())
                unique, first, counts = np.unique(values,return_index=True,return_counts=True)
                has_repeat = np.any(counts>1)
                period = int(r["period"])
                period_ok &= has_repeat == (period>0)
                if period:
                    start,end = int(r["first_repeat_start"]),int(r["first_repeat_end"])
                    period_ok &= end-start == period and end < len(values) and np.array_equal(values[start:-period],values[end:])
        checks[f"independent_metrics_{dtype}"] = bool(metric_ok)
        checks[f"exact_period_suffix_{dtype}"] = bool(period_ok)
    for group in summary["groups"]:
        subset = [r for r in rows if r["dtype"] == group["dtype"] and float(r["alpha"]) == group["alpha"]
                  and r["initial_distribution"] == group["initial_distribution"] and int(r["length"]) == max(config["observation_lengths"])]
        complete = all(r["completed"] == "True" for r in subset)
        passed = complete and np.median([float(r["mad_relative_error"]) for r in subset]) <= config["gates"]["max_group_median_mad_relative_error"] and np.median([float(r["lyapunov_absolute_error"]) for r in subset]) <= config["gates"]["max_group_median_lyapunov_absolute_error"]
        checks[f"group_{group['dtype']}_{group['alpha']}_{group['initial_distribution']}"] = bool(passed == group["passed"])
    root = Path(__file__).resolve().parents[2]
    checks["source_hashes"] = all(hashlib.sha256((root/p).read_bytes()).hexdigest() == h for p,h in env["source_sha256"].items())
    checks["artifact_hashes"] = all(hashlib.sha256((out/p).read_bytes()).hexdigest() == h
        for h,p in (line.split("  ",1) for line in (out/"sha256.txt").read_text(encoding="utf-8").splitlines()))
    result = dict(passed=all(checks.values()),checks=checks,quadrature=theory,
                  interpretation="Artifact integrity is separate from scientific gate success.")
    (out/"validation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path(__file__).resolve().parent/"artifacts"/"boole_local_validation")
    args = parser.parse_args()
    raise SystemExit(0 if validate(args.output) ["passed"] else 1)

